﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LamborghiniAuto.Models
{
    public class Finanza
    {
        public int id { get; set; }

        public double entrate { get; set; }

        public double uscite { get; set; }

        public double ricavi { get; set; }

        public Finanza()
        {

        }
    }
}
